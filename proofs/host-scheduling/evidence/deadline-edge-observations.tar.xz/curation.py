"""Retain two observed deadline-edge counterexamples from qualification run 41790256050."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

source = Path('build/issue362-attempt6/scheduler-evidence')
output = Path('build/issue362-deadline-edges')
output.mkdir(exist_ok=False)
shutil.copytree(source / 'proof-sources', output / 'proof-sources', ignore=shutil.ignore_patterns('__pycache__'))
selected = {'native-root-existing': ('edge-0-', [1, 0]),
            'container-perfmon-hostpid': ('edge-2-', [0, 1])}
for environment, (prefix, expected_codes) in selected.items():
    original = source / environment
    target = output / environment
    target.mkdir()
    rows = json.loads((original / 'results.json').read_text())
    rows = [row for row in rows if row['name'].startswith(prefix)]
    assert [row['run']['exit_code'] for row in rows] == expected_codes
    shutil.copy2(original / 'identity.json', target / 'identity.json')
    shutil.copy2(original / 'results.json', target / 'original-results.json')
    shutil.copy2(original / 'integrity.json', target / 'original-integrity.json')
    for row in rows:
        shutil.copytree(original / row['name'], target / row['name'])
    (target / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    inventory = {}
    for path in sorted(target.rglob('*')):
        if path.is_file():
            inventory[str(path.relative_to(target))] = hashlib.sha256(path.read_bytes()).hexdigest()
    (target / 'integrity.json').write_text(json.dumps(inventory, indent=2) + '\n')
    subprocess.run([sys.executable, str(output / 'proof-sources/validate.py'), str(target)], check=True)
shutil.copy2(__file__, output / 'curation.py')
(output / 'retention.json').write_text(json.dumps({
    'run_url': 'https://github.com/Stevie1704/sil/actions/runs/41790256050',
    'measurement_revision': '9a9ea7f748cf65d3ec993a178ac7dbd35c75ea86f',
    'selection': selected, 'scope': 'separate earlier deadline-edge observations; never pooled with final qualification',
    'omissions': 'All other cases. Original full results/integrity inventories are retained alongside newly sealed subset inventories.'}, indent=2) + '\n')
# Bind the actual recorded revision, rather than assuming a shortened git ref.
revisions = {json.loads(p.read_text())['source_revision'] for p in output.glob('*/identity.json')}
assert len(revisions) == 1
metadata = json.loads((output / 'retention.json').read_text())
metadata['measurement_revision'] = revisions.pop()
(output / 'retention.json').write_text(json.dumps(metadata, indent=2) + '\n')
archive = Path('proofs/host-scheduling/evidence/deadline-edge-observations.tar.xz')
assert not archive.exists()
with tarfile.open(archive, 'w:xz') as tar:
    for path in sorted(output.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            tar.add(path, arcname=str(path.relative_to(output)), recursive=False)
with (archive.parent / 'archive.sha256').open('a') as hashes:
    hashes.write(f'{hashlib.sha256(archive.read_bytes()).hexdigest()}  {archive.name}\n')
print(archive.stat().st_size)
